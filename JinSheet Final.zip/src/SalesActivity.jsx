// // import React, {useState,useEffect} from "react";
// // import "./App.js";
// // import Table from '@mui/material/Table';
// // import TableBody from '@mui/material/TableBody';
// // import TableCell from '@mui/material/TableCell';
// // import TableContainer from '@mui/material/TableContainer';
// // import TableHead from '@mui/material/TableHead';
// // import TableRow from '@mui/material/TableRow';
// // import Select from "react-select";
// // import useAutocomplete from '@mui/material/useAutocomplete';

// // function Activity(props){
// //     const ProjectList = [
// //         { value: "BAU_001", label: "BAU_001 Training & Project Knowledge" },
// //         { value: "BAU_002", label: "BAU_002 People" },
// //         { value: "BAU_003", label: "BAU_003 Delevery" },
// //         { value: "BAU_004", label: "BAU_004 Sales" },

// //       ];

// //       const TaskList = [
// //         { value: "red", label: "Red" },
// //         { value: "green", label: "Green" },
// //         { value: "yellow", label: "Yellow" },
// //         { value: "blue", label: "Blue" },
// //         { value: "white", label: "White" }
// //       ];



// //       const [selectedOptions, setSelectedOptions] = useState();
// //       function handleSelect(data) {
// //         setSelectedOptions(data);
// //       }
// //       const [numberValue, setNumberValue] = useState('');

// //       const handleInputChange = (e) => {
// //         const inputValue = e.target.value;
// //         // Check if the input is less than 8 or empty before updating the state
// //         if (inputValue === '' || (inputValue >= 0 && inputValue <= 8)) {
// //           setNumberValue(inputValue);
// //         }
// //       };

// //       const [bauActivity, setbauActivity] = useState([]);
// //       const [newbauActivity, setNewbauActivity] = useState("");

    
// //       useEffect(() => {
// //         let bauActivity = JSON.parse(localStorage.getItem("bauActivityList"));
    
// //         if (bauActivity) {
// //           setbauActivity(bauActivity);
// //         }
// //       }, []);
    
// //       const handleAddNewToDo = () => {
// //         let newToDoObj = {
// //           id: Date.now(), // generates a unique id using dates and time
// //           ProjectType: props.ProjectType,
// //           ProjectName:selectedOptions,
// //           Task:Task,
// //           Comment:Comment,
// //           Mon:monValue,
// //           Tue:tueVale,
// //           Wed:wedValue,
// //           Thu:thuValue,
// //           Fri:friValue,
// //           Sat:satValue,
// //           Sun:sunValue,
// //         };
    
// //         let updatedTodoArr = [...allTodos];
// //         updatedTodoArr.push(newToDoObj);
    
// //         setAllTodos(updatedTodoArr);
// //         localStorage.setItem(`{props.ProjectType}`, JSON.stringify(updatedTodoArr));
    
// //         setNewTodo("");
// //       };
// //     return(


// // <TableRow >


// //             <TableCell className='table-body'> {props.ProjectType}</TableCell>
// //             <TableCell className='table-body' align="right">
// //             <div className="dropdown-container">
// //       <Select
// //         options={ProjectList}
// //         className="projectList"
// //         placeholder="Project Name"
// //         value={selectedOptions}
// //         onChange={handleSelect}
// //         isSearchable={true}
// //       />
// //     </div></TableCell>
// //             <TableCell className='table-body' align="right"><input type="text" value={Task} placeholder="comments" required/></TableCell>
// //             <TableCell className='table-body' align="right"><input type="text" value={Comment} placeholder="comments" /></TableCell>
// //             <TableCell id='table-body-hours' align="right"> <input
// //             className="table-body-hours"
// //         type="number"
// //         id="monInput"
// //         name="monInput"
// //         value={monValue}
// //         onChange={handleInputChange}
// //         max="8"
// //         required
// //       /></TableCell>
// //             <TableCell id='table-body-hours' align="right"> 
// //             <input
// //             className="table-body-hours"
// //         type="number"
// //         id="tueInput"
// //         name="tueInput"
// //         value={numberValue}
// //         onChange={handleInputChange}
// //         max="8"
// //         required
// //       />
// //       </TableCell>
// //             <TableCell id='table-body-hours' align="right"> <input
// //             className="table-body-hours"
// //         type="number"
// //         id="wedInput"
// //         name="wedInput"
// //         value={numberValue}
// //         onChange={handleInputChange}
// //         max="8"
// //         required
// //       /></TableCell>
// //             <TableCell id='table-body-hours' align="right"> <input
// //             className="table-body-hours"
// //         type="number"
// //         id="thuInput"
// //         name="thuInput"
// //         value={numberValue}
// //         onChange={handleInputChange}
// //         max="8"
// //         required
// //       /></TableCell>
            
// //             <TableCell id='table-body-hours' align="right"> <input
// //             className="table-body-hours"
// //         type="number"
// //         id="friInput"
// //         name="friInput"
// //         value={numberValue}
// //         onChange={handleInputChange}
// //         max="8"
// //         required
// //       /></TableCell>
// //             <TableCell id='table-body-hours' align="right"> <input
// //             className="table-body-hours"
// //         type="number"
// //         id="satInput"
// //         name="satInput"
// //         value={numberValue}
// //         onChange={handleInputChange}
// //         max="8"
// //         required
// //       /></TableCell>
// //             <TableCell id='table-body-hours' align="right"> <input
// //             className="table-body-hours"
// //         type="number"
// //         id="sunInput"
// //         name="sunInput"
// //         value={numberValue}
// //         onChange={handleInputChange}
// //         max="8"
// //         required
// //       /></TableCell>
// //       <TableCell>
// //       <button
// //                 className="primaryBtn"
// //                 type="button"
// //                 onClick={handleAddNewToDo}
// //               >
// //                 Add
// //               </button>
// //       </TableCell>
      
// //           </TableRow>

// //     )
// // };

// // export default Activity;



// import React, { useState, useEffect } from "react";
// import Select from "react-select";
// import TableRow from '@mui/material/TableRow';
// import TableCell from '@mui/material/TableCell';
// import { MdDelete } from "react-icons/md";
// import { IoIosAddCircle } from "react-icons/io";
// function SalesActivity(props) {
//     const ProjectList = [
//       { value: "BAU_001", label: "BAU_001 Training & Project Knowledge" },
//       { value: "BAU_002", label: "BAU_002 People" },
//       { value: "BAU_003", label: "BAU_003 Delivery" },
//       { value: "BAU_004", label: "BAU_004 Sales" },
//     ];

//     const [selectedOptions, setSelectedOptions] = useState();
//     function handleSelect(data) {
//       setSelectedOptions(data);
//     }

//     const [Task, setTask] = useState('');
// const [Comment, setComment] = useState('');
// const [monValue, setMonValue] = useState('');
// const [tueValue, setTueValue] = useState('');
// const [wedValue, setWedValue] = useState('');
// const [thuValue, setThuValue] = useState('');
// const [friValue, setFriValue] = useState('');
// const [satValue, setSatValue] = useState('');
// const [sunValue, setSunValue] = useState('');

// // const [bauActivity, setbauActivity] = useState([]);
// const [salesActivity, setsalesActivity] = useState([]);

//   useEffect(() => {
//     // let bauActivity = JSON.parse(localStorage.getItem("bauActivityList"));
//     let salesActivity = JSON.parse(localStorage.getItem("salesActivityList"));
//     // if (bauActivity) {
//     //   setbauActivity(bauActivity);
//     // }

//     if(salesActivity){
//         setsalesActivity(salesActivity);
//     }

//   }, []);


//   const handleAddNewToDo = () => {
//     let newToDoObj = {
//       id: Date.now(),
//       ProjectType: props.ProjectType,
//       ProjectName: selectedOptions?.label || "",
//       Task: Task,
//       Comment: Comment,
//       Mon: monValue,
//       Tue: tueValue,
//       Wed: wedValue,
//       Thu: thuValue,
//       Fri: friValue,
//       Sat: satValue,
//       Sun: sunValue,
//     };
  
//     // if (props.ProjectType === 'BAU Activity') {
//     //   let updatedbauActivityArr = [...bauActivity, newToDoObj];
//     //   setbauActivity(updatedbauActivityArr);
//     //   localStorage.setItem("bauActivityList", JSON.stringify(updatedbauActivityArr));
//     // }
  
//     // if (props.ProjectType === 'Sales Activity') {
//       let updatedsalesActivityArr = [...salesActivity, newToDoObj];
//       setsalesActivity(updatedsalesActivityArr);
//       localStorage.setItem("salesActivityList", JSON.stringify(updatedsalesActivityArr));
//     // }
  
//     // Clear the input fields after adding a new todo
//     setTask('');
//     setComment('');
//     setMonValue('');
//     setTueValue('');
//     setWedValue('');
//     setThuValue('');
//     setFriValue('');
//     setSatValue('');
//     setSunValue('');
//   };
  

//   const handleToDoDelete = (id) => {

//     // if(props.ProjectType==="BAU Activity"){
//     //     const updatedbauActivity = bauActivity.filter((activity) => activity.id !== id);

//     //     localStorage.setItem("bauActivityList", JSON.stringify(updatedbauActivity));
//     //     setbauActivity(updatedbauActivity);
//     // }

//     // if(props.ProjectType==="Sales Activity"){
//         const updatedsalesActivity = salesActivity.filter((activity) => activity.id !== id);

//         localStorage.setItem("salesActivityList", JSON.stringify(updatedsalesActivity));
//         setsalesActivity(updatedsalesActivity);
//     // }
    
//   };

//   return (
//     <>
//     <TableRow>
//       <TableCell className='table-body'> Sales Activity</TableCell>
//       <TableCell className='table-body' align="right">
//         <div className="dropdown-container">
//           <Select
//             options={ProjectList}
//             className="projectList"
//             placeholder="Project Name"
//             value={selectedOptions}
//             onChange={handleSelect}
//             isSearchable={true}
//           />
//         </div>
//       </TableCell>
//       <TableCell className='table-body' align="right">
//         <input type="text" value={Task} onChange={(e) => setTask(e.target.value)} placeholder="Task" required />
//       </TableCell>
//       <TableCell className='table-body' align="right">
//         <input type="text" value={Comment} onChange={(e) => setComment(e.target.value)} placeholder="Comment" />
//       </TableCell>
//       <TableCell className='table-body-hours' align="right">
//         <input
//           className="table-body-hours"
//           type="number"
//           id="monInput"
//           name="monInput"
//           value={monValue}
//           onChange={(e) => setMonValue(e.target.value)}
//           max="8"
//           required
//         />
//       </TableCell>
//       <TableCell className='table-body-hours' align="right">
//         <input
//           className="table-body-hours"
//           type="number"
//           id="tueInput"
//           name="tueInput"
//           value={tueValue}
//           onChange={(e) => setTueValue(e.target.value)}
//           max="8"
//           required
//         />
//       </TableCell>
      
//       <TableCell className='table-body-hours' align="right">
//         <input
//           className="table-body-hours"
//           type="number"
//           id="wedInput"
//           name="wedInput"
//           value={wedValue}
//           onChange={(e) => setWedValue(e.target.value)}
//           max="8"
//           required
//         />
//       </TableCell>

//       <TableCell className='table-body-hours' align="right">
//         <input
//           className="table-body-hours"
//           type="number"
//           id="thuInput"
//           name="thuInput"
//           value={thuValue}
//           onChange={(e) => setThuValue(e.target.value)}
//           max="8"
//           required
//         />
//       </TableCell>

//       <TableCell className='table-body-hours' align="right">
//         <input
//           className="table-body-hours"
//           type="number"
//           id="friInput"
//           name="friInput"
//           value={friValue}
//           onChange={(e) => setFriValue(e.target.value)}
//           max="8"
//           required
//         />
//       </TableCell>

//       <TableCell className='table-body-hours' align="right">
//         <input
//           className="table-body-hours"
//           type="number"
//           id="satInput"
//           name="satInput"
//           value={satValue}
//           onChange={(e) => setSatValue(e.target.value)}
//           max="8"
//           required
//         />
//       </TableCell>
//       <TableCell className='table-body-hours' align="right">
//         <input
//           className="table-body-hours"
//           type="number"
//           id="sunInput"
//           name="sunInput"
//           value={sunValue}
//           onChange={(e) => setSunValue(e.target.value)}
//           max="8"
//           required
//         />
//       </TableCell>

//       <TableCell>
//       <IoIosAddCircle title="Add?"
//                 className="add-icon"
//                 onClick={handleAddNewToDo} />
//       </TableCell>
//       <TableCell>
     
//       </TableCell>
//     </TableRow>
//     {bauActivity.map((activity) => (
//             <TableRow className="table-body" key={activity.id}>
//             <TableCell className='table-body'> {activity.ProjectType}</TableCell>
//       <TableCell className='table-body' align="right">
//         {activity.ProjectName}
//       </TableCell>
//       <TableCell className='table-body' align="right">
//         {activity.Task}
//       </TableCell>
//       <TableCell className='table-body' align="right">
//         {activity.Comment}
//       </TableCell>
//       <TableCell className='table-body-hours' align="right">
//         {activity.Mon}
//       </TableCell>
//       <TableCell className='table-body-hours' align="right">
//         {activity.Tue}
//       </TableCell>
      
//       <TableCell className='table-body-hours' align="right">
//         {activity.Wed}
//       </TableCell>

//       <TableCell className='table-body-hours' align="right">
//         {activity.Thu}
//       </TableCell>

//       <TableCell className='table-body-hours' align="right">
//         {activity.Fri}
//       </TableCell>

//       <TableCell className='table-body-hours' align="right">
//        {activity.Sat}
//       </TableCell>
//       <TableCell className='table-body-hours' align="right">
//        {activity.Sun}
//       </TableCell>

//       <TableCell>
//       <IoIosAddCircle title="Add?"
//                 className="add-icon"
//                 onClick={handleAddNewToDo} />
             

//               <MdDelete
//                 title="Delete?"
//                 className="delete-icon"
//                 onClick={() => handleToDoDelete(activity.id)}
//               />
//                 </TableCell>
//             </TableRow>
//           ))}
//     </>
//   );
// }

// export default SalesActivity;