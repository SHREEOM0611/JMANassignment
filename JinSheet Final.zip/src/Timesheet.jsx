import React from "react";
import "./App.css";
import Extension from "./Extension";
import TimeSheetData from "./TimeSheetData.jsx";

function Timesheet() {
  return (
    <div id="timesheet ">
     <h1 >Timesheet</h1>
     <Extension />
     <TimeSheetData />
    </div>
  );
}

export default Timesheet;
