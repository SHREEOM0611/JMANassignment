import * as React from 'react';
import "./App.css"
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';


export default function ExtensionTable() {
  return (
    <TableContainer component={Paper}>
      <Table sx={{ minWidth: 650 }} aria-label="simide table">
        <TableHead>
          <TableRow >
            <TableCell id='table-header'> Project Name</TableCell>
            <TableCell id='table-header' align="right">Project Type</TableCell>
            <TableCell id='table-header' align="right">Project End&nbsp;</TableCell>
            <TableCell id='table-header' align="right">Allocation End&nbsp;</TableCell>
            <TableCell id='table-header' align="right">Allocation Extension &nbsp;</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
         {/* <TableRow >
          <p>No options available</p>
         </TableRow> */}
         
        </TableBody>
        
      </Table>
      <p style={{textAlign:'center'}}>No options available</p>
    </TableContainer>
  );
}