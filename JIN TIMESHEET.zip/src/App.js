import React from "react";
import "./App.css";
import SidebarMenu from "./SidebarMenu";
import Timesheet from "./Timesheet";

function App() {
  return (
    <div id="App " className="row">
      <SidebarMenu />
      <Timesheet />
    </div>
  );
}

export default App;
