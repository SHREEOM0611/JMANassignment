import React from "react";
import "./App.css";
import Extension from "./Extension";

function Timesheet() {
  return (
    <div className="timesheet col-lg-9 col-md-8 col-12">
     <h1 >Timesheet</h1>
     <Extension />
    </div>
  );
}

export default Timesheet;
