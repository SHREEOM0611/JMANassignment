import React, { useState, useEffect } from "react";
import Select from "react-select";
import TableRow from '@mui/material/TableRow';
import TableCell from '@mui/material/TableCell';
import { MdDelete } from "react-icons/md";
import { IoIosAddCircle } from "react-icons/io";
function Activity(props) {
    const ProjectList = [
      { value: "BAU_001", label: "BAU_001 " },
      { value: "BAU_002", label: "BAU_002 " },
      { value: "BAU_003", label: "BAU_003 " },
      { value: "BAU_004", label: "BAU_004 " },
    ];

    const [selectedOptions, setSelectedOptions] = useState();
    function handleSelect(data) {
      setSelectedOptions(data);
    }

const [Task, setTask] = useState('');
const [Comment, setComment] = useState('');
const [monValue, setMonValue] = useState(0);
const [tueValue, setTueValue] = useState(0);
const [wedValue, setWedValue] = useState(0);
const [thuValue, setThuValue] = useState(0);
const [friValue, setFriValue] = useState(0);
const [satValue, setSatValue] = useState(0);
const [sunValue, setSunValue] = useState(0);

const [bauActivity, setbauActivity] = useState([]);
const [salesActivity, setsalesActivity] = useState([]);

  useEffect(() => {
    let bauActivity = JSON.parse(localStorage.getItem("bauActivityList"));
    let salesActivity = JSON.parse(localStorage.getItem("salesActivityList"));
    if (bauActivity) {
      setbauActivity(bauActivity);
    }

    if(salesActivity){
        setsalesActivity(salesActivity);
    }

  }, []);


  const handleAddNewToDo = () => {
    let newToDoObj = {
      id: Date.now(),
      ProjectType: props.ProjectType,
      ProjectName: selectedOptions?.label || "",
      Task: Task,
      Comment: Comment,
      Mon: monValue,
      Tue: tueValue,
      Wed: wedValue,
      Thu: thuValue,
      Fri: friValue,
      Sat: satValue,
      Sun: sunValue,
      TotalHours:parseInt(monValue)+parseInt(tueValue)+parseInt(wedValue)+parseInt(thuValue)+parseInt(friValue)+parseInt(satValue)+parseInt(sunValue),
    };
  
    if (props.ProjectType === 'BAU Activity') {
      let updatedbauActivityArr = [...bauActivity, newToDoObj];
      setbauActivity(updatedbauActivityArr);
      localStorage.setItem("bauActivityList", JSON.stringify(updatedbauActivityArr));
    }
  
    if (props.ProjectType === 'Sales Activity') {
      let updatedsalesActivityArr = [...salesActivity, newToDoObj];
      setsalesActivity(updatedsalesActivityArr);
      localStorage.setItem("salesActivityList", JSON.stringify(updatedsalesActivityArr));
    }
  
    // Clear the input fields after adding a new todo
    setTask('');
    setComment('');
    setMonValue(0);
    setTueValue(0);
    setWedValue(0);
    setThuValue(0);
    setFriValue(0);
    setSatValue(0);
    setSunValue(0);
  };
  

  const handleToDoDelete = (id) => {

    if(props.ProjectType==="BAU Activity"){
        const updatedbauActivity = bauActivity.filter((activity) => activity.id !== id);

        localStorage.setItem("bauActivityList", JSON.stringify(updatedbauActivity));
        setbauActivity(updatedbauActivity);
    }

    if(props.ProjectType==="Sales Activity"){
        const updatedsalesActivity = salesActivity.filter((activity) => activity.id !== id);

        localStorage.setItem("salesActivityList", JSON.stringify(updatedsalesActivity));
        setsalesActivity(updatedsalesActivity);
    }
  };
let mainActivity;
  if(props.ProjectType==='BAU Activity'){
    mainActivity=bauActivity;
  }
  if(props.ProjectType==='Sales Activity'){
    mainActivity=salesActivity;
  }


  return (
    <>
    <TableRow>
      <TableCell className='table-body'> {props.ProjectType}</TableCell>
      <TableCell className='table-body' align="right">
        <div className="dropdown-container">
          <Select
            options={ProjectList}
            className="projectList"
            placeholder="Project Name"
            value={selectedOptions}
            onChange={handleSelect}
            isSearchable={true}
            required
          />
        </div>
      </TableCell>
      <TableCell id='table-body' align="right">
        <input type="text" value={Task} onChange={(e) => setTask(e.target.value)} placeholder="Task" required />
      </TableCell>
      <TableCell id='table-body' align="right">
        <input type="text" value={Comment} onChange={(e) => setComment(e.target.value)} placeholder="Comment" />
      </TableCell>
      <TableCell className='table-body-hours' align="right">
        <input
        
          type="number"
          id="monInput"
          name="monInput"
          value={monValue}
          onChange={(e) => setMonValue(e.target.value)}
          max="8"
          required
        />
      </TableCell>
      <TableCell className='table-body-hours' align="right">
        <input
         
          type="number"
          id="tueInput"
          name="tueInput"
          value={tueValue}
          onChange={(e) => setTueValue(e.target.value)}
          max="8"
          required
        />
      </TableCell>
      
      <TableCell className='table-body-hours' align="right">
        <input
        
          type="number"
          id="wedInput"
          name="wedInput"
          value={wedValue}
          onChange={(e) => setWedValue(e.target.value)}
          max="8"
          required
        />
      </TableCell>

      <TableCell className='table-body-hours' align="right">
        <input
        
          type="number"
          id="thuInput"
          name="thuInput"
          value={thuValue}
          onChange={(e) => setThuValue(e.target.value)}
          max="8"
          required
        />
      </TableCell>

      <TableCell className='table-body-hours' align="right">
        <input
      
          type="number"
          id="friInput"
          name="friInput"
          value={friValue}
          onChange={(e) => setFriValue(e.target.value)}
          max="8"
          required
        />
      </TableCell>

      <TableCell className='table-body-hours' align="right">
        <input
          
          type="number"
          id="satInput"
          name="satInput"
          value={satValue}
          onChange={(e) => setSatValue(e.target.value)}
          max="8"
          required
        />
      </TableCell>
      <TableCell className='table-body-hours' align="right">
        <input
        
          type="number"
          id="sunInput"
          name="sunInput"
          value={sunValue}
          onChange={(e) => setSunValue(e.target.value)}
          max="8"
          required
        />
      </TableCell>
      <TableCell>
      
      </TableCell>
      <TableCell>
      <IoIosAddCircle title="Add?"
                className="add-icon"
                onClick={handleAddNewToDo} />
      </TableCell>
   
    </TableRow>
    {mainActivity.map((activity) => (
            <TableRow className="table-body " key={activity.id}>
            <TableCell className='table-body'> {activity.ProjectType}</TableCell>
      <TableCell id='table-body'  align="right">
        <div className="entered-data"> {activity.ProjectName}</div>
       
      </TableCell>
      <TableCell id='table-body'  align="right">
      <div className="entered-data">  {activity.Task}</div>
       
      </TableCell>
      <TableCell id='table-body'  align="right">
      <div className="entered-data">   {activity.Comment}</div>
       
      </TableCell>
      <TableCell id='table-body-hours' align="right">
      <div className="entered-data">  {activity.Mon}</div>
        
      </TableCell>
      <TableCell id='table-body-hours'  align="right">
      <div className="entered-data">  {activity.Tue}</div>
        
      </TableCell>
      
      <TableCell id='table-body-hours'  align="right">
      <div className="entered-data">    {activity.Wed}</div>
      
      </TableCell>

      <TableCell id='table-body-hours'  align="right">
      <div className="entered-data"> {activity.Thu}</div>
        
      </TableCell>

      <TableCell className='table-body-hours' align="right">
      <div className="entered-data">{activity.Fri}</div>
        
      </TableCell>

      <TableCell id='table-body-hours'  align="right">
      <div className="entered-data">{activity.Sat}</div>
      
      </TableCell>
      <TableCell id='table-body-hours'  align="right">
      <div className="entered-data"> {activity.Sun}</div>
     
      </TableCell>
      <TableCell>
      <div className="entered-data">   {activity.TotalHours}</div>
      </TableCell>
      <TableCell>
      <IoIosAddCircle title="Add?"
                className="add-icon"
                onClick={handleAddNewToDo} />
             

              <MdDelete
                title="Delete?"
                className="delete-icon"
                onClick={() => handleToDoDelete(activity.id)}
              />
                </TableCell>
            </TableRow>
          ))}
    </>
  );
}

export default Activity;