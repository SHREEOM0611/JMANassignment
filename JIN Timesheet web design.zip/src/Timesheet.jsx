import React from "react";
import "./App.css";
import Extension from "./Extension";
import TimeSheetData from "./TimeSheetData.jsx";
import "bootstrap/dist/css/bootstrap.css";

function Timesheet() {
  return (
    <div id="timesheet " className="col-lg-9 col-md-8 col-sm-12 m-0">
     <h1 >Timesheet</h1>
     <Extension />
     <TimeSheetData />
    </div>
  );
}

export default Timesheet;
