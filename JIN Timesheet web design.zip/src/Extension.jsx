import React,{useState} from "react";
import "./App.css";
import 'bootstrap/dist/css/bootstrap.css';
import { MDBCollapse, MDBBtn } from 'mdb-react-ui-kit';
import ExtensionTable from "./ExtensionTable";

function Extension() {
    const [isOpen, setIsOpen] = useState(false);

  const toggleOpen = () => setIsOpen(!isOpen);
  return (
    <div className="extension">
        <div className="ext-btn" onClick={toggleOpen}> Allocation Extension</div>
       
      <MDBCollapse open={isOpen}>
       <ExtensionTable />
      </MDBCollapse>
     </div>
  );
}

export default Extension;
