import React, {useState, useEffect} from "react";
import "./App.css"
import Activity from "./Activity.jsx";
// import SalesActivity from "./SalesActivity.jsx";
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';


function TimeSheetData(){

return(
<div className="timesheet-data">
<div className="timesheet-data-header" > Timesheet</div>
<TableContainer component={Paper}>
      <Table sx={{ minWidth: 650 }} aria-label="simple table">
        <TableHead id="timesheet-table-header">
          <TableRow id="timesheet-table-header" >
            <TableCell id='table-header'> Project Type</TableCell>
            <TableCell id='table-header' align="right">Project Name</TableCell>
            <TableCell id='table-header' align="right">Task</TableCell>
            <TableCell id='table-header' align="right">Comment</TableCell>
            <TableCell id='table-header' className='table-body-hours col' align="right"> <p className="row-lg-12">Mon</p><p className="row-lg-12">05</p></TableCell>
            <TableCell id='table-header' className='table-body-hours col' align="right"> <p className="row-lg-12">Tue</p><p className="row-lg-12">06</p></TableCell>
            <TableCell id='table-header' className='table-body-hours col' align="right"> <p className="row-lg-12">Wed</p><p className="row-lg-12">07</p></TableCell>
            <TableCell id='table-header' className='table-body-hours col' align="right"> <p className="row-lg-12">Thu</p><p className="row-lg-12">08</p></TableCell>
            <TableCell id='table-header' className='table-body-hours col' align="right"> <p className="row-lg-12">Fri</p><p className="row-lg-12">09</p></TableCell>
            <TableCell id='table-header' className='table-body-hours col' align="right"> <p className="row-lg-12">Sat</p><p className="row-lg-12">10</p></TableCell>
            <TableCell id='table-header' className='table-body-hours col' align="right"> <p className="row-lg-12">Sun</p><p className="row-lg-12">11</p></TableCell>
            <TableCell id='table-header' className='table-body-hours' align="right">Total Hours</TableCell>
            <TableCell id='table-header' className='table-body-hours' align="right"></TableCell>
       
  </TableRow>
        </TableHead>
        <TableBody>
          <Activity ProjectType="BAU Activity" />
          <Activity ProjectType="Sales Activity" />
    

        </TableBody>
      </Table>
    </TableContainer>
</div>

    );
}

export default TimeSheetData;