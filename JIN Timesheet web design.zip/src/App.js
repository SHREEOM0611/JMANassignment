import React from "react";
import "./App.css";
import SidebarMenu from "./SidebarMenu";
import Timesheet from "./Timesheet";
import "bootstrap/dist/css/bootstrap.css";
import { ProSidebarProvider } from "react-pro-sidebar";

function App() {
  return (
    <div id="App " className="row">
      <SidebarMenu className="col-lg-2" />
      <Timesheet className="col-lg-8" />
    </div>
  );
}

export default App;
